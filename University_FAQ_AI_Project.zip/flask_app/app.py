
from flask import Flask, render_template, request
import difflib

app = Flask(__name__)

faq_data = {
    "what are the admission requirements?": "You need at least 45% marks in FA/FSc for undergraduate programs.",
    "how can i apply for admission?": "You can apply online through the official University of Malakand website.",
    "what is the semester promotion rule?": "Students must pass at least 50% of total credit hours to be promoted to the next semester.",
    "what is the fee structure?": "The fee structure is available on the university website under the 'Admissions' section."
}

def get_best_match(user_question):
    questions = faq_data.keys()
    match = difflib.get_close_matches(user_question.lower(), questions, n=1, cutoff=0.5)
    if match:
        return faq_data[match[0]]
    else:
        return "Sorry, I don't have an answer to that. Please contact the university office."

@app.route("/", methods=["GET", "POST"])
def index():
    answer = ""
    if request.method == "POST":
        question = request.form["question"]
        answer = get_best_match(question)
    return render_template("index.html", answer=answer)

if __name__ == "__main__":
    app.run(debug=True)
