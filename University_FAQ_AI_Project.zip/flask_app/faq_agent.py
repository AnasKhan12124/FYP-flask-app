
import difflib

# Rule-based FAQs
faq_data = {
    "what are the admission requirements?": "You need at least 45% marks in FA/FSc for undergraduate programs.",
    "how can i apply for admission?": "You can apply online through the official University of Malakand website.",
    "what is the semester promotion rule?": "Students must pass at least 50% of total credit hours to be promoted to the next semester.",
    "what is the fee structure?": "The fee structure is available on the university website under the 'Admissions' section."
}

def get_best_match(user_question):
    questions = faq_data.keys()
    match = difflib.get_close_matches(user_question.lower(), questions, n=1, cutoff=0.5)
    if match:
        return faq_data[match[0]]
    else:
        return "Sorry, I don't have an answer to that. Please contact the university office."

def main():
    print("Welcome to University of Malakand FAQ AI Agent!")
    while True:
        user_input = input("\nAsk your question (or type 'exit' to quit): ")
        if user_input.lower() == 'exit':
            print("Thank you for using the AI agent. Goodbye!")
            break
        response = get_best_match(user_input)
        print("Answer:", response)

if __name__ == "__main__":
    main()
